# Theory and methods working draft

Status: 2026-10-08; definitions and proposed tests, not an evidence-complete paper.
The research design fixes pure periodic HfO₂, zero temperature and zero electric
field. Numerical sections must ultimately name the effective electronic inputs,
mechanical ensemble, ordered atom correspondence and structural variants.

## 1. From NEB to atomic–cell paths

For an ordinary NEB, internal images represent a discrete path connecting two
fixed endpoints. The physical force perpendicular to the local tangent relaxes
the path, while a tangential spring force controls image spacing. A small NEB
residual does not imply that the physical tangential force at every image is
zero; only a properly refined stationary transition structure can support such
an assertion. Therefore the highest sampled image is a transition-state
candidate, not a transition-state certificate.

Variable-cell paths extend the active coordinates to atomic displacements and
cell deformation. We retain an explicit reference cell, ordered atoms, periodic
image choices and a length scale for strain coordinates. Cell rotations and
rigid translations are not reaction coordinates. This is an implementation of
established variable-cell/solid-state NEB ideas, not a new NEB theory. The
optimizer and mechanical active-space projection act on energy/force/stress
results through an ASE-compatible interface independently of the backend.

Periodic lifts are part of the input contract: independent image wrapping can
leave all DFT observables correct while introducing spurious jumps into the
unwrapped tangent/spring metric. Under an explicitly declared short-adjacent-
step convention, integer lattice shifts are registered before computation
and the optimizer rejects an inconsistent supplied lift. No runtime remapping
or structural repair is performed. Half-cell ambiguities require additional
path information. Geometry-contract correctness is an engineering prerequisite,
not evidence of accelerated convergence or a new scientific method.

Under hydrostatic pressure the objective is H=E+PV. At fixed epitaxial vectors
and zero external normal/shear loading, the objective is E restricted to the
declared movable variables. A nonzero constrained stress is a substrate
reaction, not failed convergence. Every image and both endpoints of a channel
must obey the same substrate matrix. Released and clamped zero-strain cells
are distinct ensembles, even if their nominal strain labels coincide.

## 2. Channel selectivity requires a common initial state

For a channel α from the same initial structure I, write

`B_α(c) = E†_α(c) - E_I(c)`,

where c denotes a mechanical condition and E† is the relevant stationary
bottleneck energy, or explicitly a provisional sampled maximum. The identity

`B_α - B_β = E†_α - E†_β`

shows that the common initial-well energy cancels. A changed PO well depth
alone cannot explain a changed barrier *difference* between two routes from
that PO state. Absolute barriers, phase energy differences and channel
selectivity are therefore reported separately. Formation T→PO and decay
PO→M do not share an initial state and are not compared as competing branching
rates merely by their forward barriers. Reverse barriers obey
`B_forward - B_reverse = E_F - E_I`.

At a smooth, stationary constrained branch, the envelope derivative for a
continuously varied strain is

`dB_α/dε = dE†_α/dε - dE_I/dε`.

The derivative is evaluated through the actual strain-to-cell Jacobian and
stress convention; unequal cell volumes and biaxial factors are retained.
For same-initial-state selectivity its derivative is the difference between
the two bottleneck responses. This established identity motivates an
independently testable prediction, rather than being claimed as a new theorem.
It is not applied across a nonsmooth branch crossing or to a nonstationary
image without qualifications.

An increased decay-minus-switching barrier difference is only improved
relative selectivity. It can occur even when both absolute barriers decrease.
The stronger proposed decoupling criterion separately requires a significant
switching-barrier reduction without a resolved reduction of the easiest
examined nonpolar-decay barrier. An absolute decay-barrier increase is a
stronger outcome. Report both M and T leakage channels and measured numerical
uncertainty; do not turn relative selectivity into a device-retention claim.

## 3. Modes, local coordinates and conditional branches

Parent-symmetry distortions classify variants and signs; local phonon
eigenvectors characterize curvature at a chosen structure. They serve
different purposes. A Γ eigenvector of a tetragonal 12-atom cell is not
automatically the X2− eigenvector of a cubic parent. The parent cell and the
integer embedding/folding map are required when finite-q labels are used.
For Γ force constants of the existing 12-atom model, a 1×1×1 displacement
cell suffices; no complete phonon dispersion is implied.

A frozen two-mode slice holds unselected coordinates fixed. A conditional
branch surface instead minimizes over permitted orthogonal coordinates at
fixed mode values. The global lower envelope additionally requires all
relevant branches. These three objects must not be conflated. A large
off-plane reconstruction residual, unstable transverse direction, or branch
switch is an observable failure of a particular reduction, not a reason to
force the path onto a visually attractive plane.

Let q be retained coordinates and r orthogonal movable coordinates in a
common declared metric. For a local quadratic energy with stable H_rr,
orthogonal relaxation gives

`δr* = -H_rr^(-1)(g_r + H_rq δq)`,

`g_eff = g_q - H_qr H_rr^(-1) g_r`,

`K_eff = H_qq - H_qr H_rr^(-1) H_rq`.

At an orthogonally stationary reference g_r=0. The curvature correction is
positive semidefinite, so stable orthogonal release softens local retained
curvature in this approximation. This does **not** prove that release always
reduces an activation barrier: the initial state can relax more strongly than
the bottleneck, endpoints may change, and global branch identities may change.
With the local expansion referenced at r=0, its relaxation energy is
`ΔE_relax = -g_r^T H_rr^(-1) g_r / 2`. Comparing the initial and bottleneck
relaxation contributions is a proposed mechanism diagnostic.

The implementation refuses to invert H_rr when its minimum eigenvalue does
not exceed a measured resolution floor. Acoustic translations are removed
explicitly; a physical unstable direction is retained or assigned a separate
branch, not hidden by a pseudoinverse. The Schur complement is standard
mathematics. The candidate method contribution is a tested branch-aware
selection/augmentation workflow with predictive benefit, if the material
experiments demonstrate that benefit.

## 4. Verification and falsification design

Fixed-Hamiltonian atomic and strain probes compare finite-energy work with
analytic force/stress work at two step sizes. This checks signs, units,
coordinate Jacobians and numerical resolution without altering cutoff or
orbital sets. A local positive or negative directional curvature is not a
full Hessian index and does not certify a variable-cell saddle.

Reduced-model predictions are frozen before independent DFT holdouts. Compare
endpoint-only, atomic-mode, mode–strain-release and branch-augmented models.
Report incorrect rankings, unresolved barrier differences and necessary
extra directions alongside successes. A DFT-backed contour requires sampled
coverage, branch continuity and holdout accuracy; interpolation is not added
DFT evidence. Efficiency is measured in actual energy/force/stress calls and
core-hours, with identical physical contracts and correctly identified
channels, rather than in optimizer steps alone.

The closest prior works and pending full-text audit are listed in
`../../docs/VARNEB_JCTC_HFO2_RESEARCH_PLAN.md`. No conclusion of a favorable
strain window, novel mode coupling, accelerated convergence or JCTC-level
scientific novelty is made here before those tests.

## 5. Explicit parent-site gauge for HfO2 variants

An ideal fluorite quarter-site scaffold is embedded in the unmodified
twelve-atom T lattice. This geometric scaffold is not a separately calculated
cubic phase. A declared operation maps fractional column coordinates as
`f' = R f + t`; its species-preserving parent-site permutation is recorded
before applying it to a distorted product. Product atoms are not subsequently
relabelled by nearest-site fitting. The operation must preserve the metric
when the cell is retained. Inversion-related product structures are geometric
switching candidates; a Berry-phase branch check is a separate validation.

The four fcc translations in this cell give orthogonal character projectors
onto Gamma and the three X-wavevector sectors, in the scaffold reciprocal
axes. Their sum reconstructs the displacement after a stated translation
gauge is removed. These q sectors contain multiple irreducible representations:
an X-sector amplitude must not be called X2- without further mode identification.
Likewise, the historical T distortion is only one vector in this space;
its scalar projection is not a general channel label.

For the local T-cell dynamical matrix, generate central atomic displacements
at 0.01 and 0.02 Angstrom with a 1x1x1 supercell and identity primitive matrix.
Phonopy symmetry reduces each family to eight independent force calculations.
The Python workflow consumes Angstrom coordinates and eV/Angstrom forces,
so its force constants have units eV/Angstrom^2; it does not use the native
ABACUS Bohr-coordinate conversion factor. Raw force constants, acoustic-sum
drift and permutation asymmetry are retained. ASR/permutation symmetrization
is reported separately, and two-step disagreement is part of the uncertainty
assessment. Acoustic modes are identified by the rigid-translation subspace
overlap, not assumed to be the first three sorted frequencies. This is an
analytic fixed-cell Gamma matrix without LO-TO/NAC corrections, not a
finite-q dispersion or a joint atom-cell saddle certification.

## 6. Electronic validation of inversion-related endpoints

Geometric parent operations alone do not establish an electronic switching
branch. For the common PO starting well and two ordered inversion products,
we evaluate the native LCAO Berry polarization along the third lattice vector.
The labels PO+ and PO- refer to the registered starting/product wells, not a
choice of the smallest absolute polarization value. The original SCF geometry,
100-Ry cutoff, full10-au DZP orbitals, pseudopotentials and2x2x2 mesh are retained.
Only charge/band-gap output is added, and the resulting energy, forces and
stress must reproduce the original endpoint before further analysis.

On that fixed charge, NSCF meshes2x2x2,2x2x4 and2x2x8 test the longitudinal
quadrature. Their total energies are excluded from activation barriers.
The actual ABACUS3.10.0/f7cb1d3 native output and48 occupied bands are audited:
the96-electron count follows from the actual Hf/O UPF valences12/6. For this
version LCAO NSCF eigenvalues require explicit band output; a completed Berry
log does not itself establish a sampled insulating gap.

For row cell vectors a_i the modern polarization quantum lattice is e*a_i/V.
The spin-paired native implementation with even ionic valences reports an
approximately doubled R3 modulus and uses older SI conversion constants.
Both the native value/modulus and the explicit modern-SI conversion are stored;
the polarization is never divided by two or assigned a physical path branch
by minimizing its magnitude. Endpoint inversion is checked modulo the native
period after unit conversion, while self-inverse classes are additionally
checked using the physical eR/V quantum. This endpoint test does not determine
the absolute spontaneous polarization, the full Cartesian polarization or
the continuously unwrapped change along either optimized switching path.
The transverse mesh is not converged by the longitudinal test.

The source-version output protocol follows the
[official native LCAO example](https://github.com/deepmodeling/abacus-develop/tree/f7cb1d3/examples/berryphase/lcao_PbTiO3)
and [Berry implementation](https://github.com/deepmodeling/abacus-develop/blob/f7cb1d3/source/module_io/berryphase.cpp).
These established Berry/unit conventions are validation requirements, not
claimed methodological innovations of VARNEB.

## 7. One mechanical ensemble for endpoints and bands

For a prescribed substrate, two non-collinear ASE row-cell vectors are held
fixed at every endpoint and image. With H=H0 F^T and their unit normal n,
the exact allowed deformation is deltaF=v n^T. Three components of v permit
normal relaxation and two out-of-plane tilts; restricting v parallel to n
instead defines a different, normal-only ensemble. The present finite strain
study selects the tilt-released ensemble. A general rotated substrate cannot
be represented by independently zeroing Cartesian stress components.

The same orthonormal deformation subspace is applied to the endpoint BFGS
filter and the NEB controller. Original seed cells are checked before general
subspace projection, rather than silently converted to a common substrate.
In-plane reaction stresses are recorded but excluded from the open-gradient
stationarity criterion. Geometry and EMT energy/stress finite differences
verify the implementation; they do not establish material barrier accuracy.

For substrate area A=|H_0 cross H_1|, moving only the third cell vector by
w performs work A w dot ((sigma+P I)n). The open-stress residual is therefore
the norm of (sigma+P I)n in the tilt-released ensemble, or its normal
projection in the normal-only ensemble. Unlike a Cartesian component test,
this criterion is invariant under a rigid change of coordinates. Endpoint
BFGS applies separate atomic-force and open-traction gates, 0.03 eV/Angstrom
and 2 kbar respectively; in-plane reaction stresses remain part of the data
but not the convergence gate. The ordinary NEB threshold remains 0.10
eV/Angstrom and is not a saddle-certification criterion.

The finite strain seeds use one proper cyclic rotation, with new Cartesian
x/y/z=old z/x/y and the same cyclic cell-row relabeling. Ordered atomic
identity is unchanged. Every phase shares the T-referenced substrate at
epsilon=0 or +0.01; +0.005 is reserved for an independent holdout. The zero
T-referenced substrate already changes the PO free-cell in-plane lengths by
approximately +3.12% and -3.61%. All affine starters consequently require
fresh clamped relaxation and independent phase/variant checks; free-cell
evaluations are not reused as their energies or forces. These prepared
geometries are not yet strain-dependent material results.

For an explicit cell derivative dotH, the fixed-fractional-coordinate work is
V(sigma+P I):(dotH^T H^{-T}). This is a branch envelope derivative only when
all open variables are stationary. On a continuous endpoint/saddle branch,
subtracting their work derivatives predicts a barrier strain response.
An ordinary NEB peak need not be a stationary saddle, and fixed-cell Gamma
phonons do not certify the joint open atom/cell Hessian index. Released P=0
and clamped epsilon=0 are compared as different boundary conditions, never
as adjacent points of a single strain derivative. These work and envelope
relations are established tools, not claims of new mathematical theory.

Curvature probes must obey the same permitted deformation subspace as the
endpoint and band. A tilt-released fixed plane admits three rank-one
deformation directions v*n^T, generally nonsymmetric. Replacing them with
the six symmetric free-cell strains would change the substrate and the
mechanical experiment. `ActiveJointCurvatureCoordinates.for_clamped_plane`
uses the exact boundary basis, retaining all atoms and removing three
translations for curvature analysis. For twelve atoms this chart has39
coordinates and36 after translation removal. Zero cell directions recover
the atomic fixed-cell chart. The historical symmetric-strain implementation
and its published-source hash are preserved separately. Geometry and EMT
work checks validate this implementation, not an HfO2 bottleneck Hessian,
its index, or independent material-barrier prediction.

For a declared orthonormal joint-coordinate direction matrix B, paired full
physical gradients measure A_j=[g(y0+h B_j)-g(y0-h B_j)]/(2h), approximating
H B. The projected matrix B^T A retains its raw reciprocity defect before
symmetrization. The transverse response A-B(B^T A) exposes coupling outside
the sampled subspace, but does not measure the complement's self-curvature.
It cannot establish stability of unsampled modes or justify their elimination.
Both directions and steps use the same chart metric and mechanical boundary;
NEB-projected and spring forces are not Hessian inputs. Signed energy checks
at two amplitudes provide an independent gradient-consistency diagnostic.
Step-size spread is not a rigorous total DFT uncertainty. The staging and
assembly interfaces call no calculator and change no physical input; separate
geometry/input/raw-SCF provenance remains required for material use.

## 8. Continuous reference projections and numerical observation audit

For a supplied, already continuous periodic lift, integer representatives are
chosen only at image zero relative to the ordered reference. The same
per-atom integer shift n is applied at every image, giving
u_i=(q_i+n-q_ref)H_ref in a fixed reference metric. Independent nearest-image
folding to the reference is not performed: it can hide a winding or introduce
artificial mode-coordinate discontinuities. Ambiguous initial half-cell
representatives, broken adjacent lifts and changed atomic order are rejected.
No calculator is invoked and no image geometry is modified by this analysis.

Cartesian geometric patterns use unit metric weights; Gamma eigenvectors
use their original phonon mass metric. Rigid translation is removed with
the corresponding weighted mean. Complete degenerate-subspace squared
amplitudes are invariant to internal basis rotations; individual mode
coordinates are not. Cell deformation F=solve(H_ref,H_i)^T and Green strain
(F^T F-I)/2 are recorded separately. This is a declared coordinate convention,
not a new decomposition theorem or a partition of energy among modes.

Every retained observation matches a complete, identical ordered SCF and
binds input, structure and raw-log checksums. Complete numeric E/F/stress
are then attached to nonexecuting SinglePointCalculator objects to reproduce
the ordinary extended-space NEB force. Atomic, cell, physical perpendicular
and spring contributions are reported separately. A residual gate, an
optimizer step limit, a scheduler exit status and full-variable saddle
stationarity are distinct checks; none is substituted for another.

## 9. Common-initial-state channel comparisons and bounded responses

For an explicit set of candidate channels, directional barriers are evaluated
from one ordered periodic initial state, raw initial energy, and mechanical
ensemble. The reverse view of an existing T--PO band supplies PO--T without
an additional path calculation. This change of thermodynamic view does not
relift atoms, change their identities or replace the source optimization
metric. Each image retains its raw energy and volume; at prescribed pressure
the profile is H_i=E_i+P V_i. Both directional maxima include the endpoints,
and B_forward-B_reverse=H_final-H_initial is checked.

Let B_s and B_d denote the minimum barriers within the explicitly declared
switching and decay candidates. If B_j lies in a measured interval[L_j,U_j],
its candidate-set minimum lies in[min_j L_j,min_j U_j]. The lowest candidate
may change within these bounds. Differences use interval subtraction rather
than an assumption of independent Gaussian errors. Missing leakage channels
block the minimum; missing numerical/sampling evidence blocks a bounded
selectivity verdict. The ordinary force threshold is not converted into a
barrier uncertainty. Numeric error and sampling audits retain separate hashes.

For S=B_d-B_s, an increased S establishes relative selectivity only; B_d
can still fall. A stronger, declared-path noninferiority comparison requires
a resolved reduction in B_s and a lower bound onDelta B_d no smaller than
-delta, with delta specified before examining responses. Error overlap
alone does not establish noninferiority. Released and clamped ensembles
are not merged into a single strain derivative. These definitions and
interval rules are conventional analysis, not new physical theory or proof
that no unexamined decay channel exists. The implementation calls no DFT
calculator and does not infer a device lifetime or switching rate.

## 10. Prospective validation scope

Before strained material labels are available, we reserve epsilon=+0.005 as
an in-range unseen condition between 0 and +0.01 within the same clamped-plane
ensemble. The candidate selected for each role uses training data only.
Predicted barriers, uncertainty bounds, branch labels, basis, code and data
hashes are fixed before complete holdout path labels are inspected. Independent
local-surface points remain outside the fitting set. A direct interpolation of
training barriers, endpoint-only responses, frozen modes, atomic-only release,
joint atomic/cell release and branch-aware reduction are compared explicitly.
Abstention on an unstable branch is a coverage result, not an accurate barrier
prediction. Two held-out edges do not certify the full network minimum.

The strict primary switching/decay test preregisters zero allowable decay-barrier
loss, separately from relative selectivity. This is an analysis margin, not an
altered calculator or NEB threshold. Unresolved intervals do not establish
noninferiority. Prediction errors and model improvements are compared against
measured reference resolution; an equally accurate interpolation baseline
precludes a claim of improved predictive precision. Corrections after inspecting
holdout labels are recorded as revised training, not successful original forecasts.

Constrained-mode landscapes and NEB-validated switching predictions are already
present in [Zhou et al. (2022)](https://doi.org/10.1126/sciadv.add5953), including
the described random-start subspace search in its supplement.
[Qi et al. (2025)](https://doi.org/10.1103/PhysRevB.111.134106) also discusses
oxygen-crossing pathways beyond its two main categories. We therefore restrict
claims to the declared candidate set, mechanical boundary and observed prediction
advantage. These sources do not establish the novelty or accuracy of our proposed
joint-cell reduction; those remain questions for the independent material tests.

[Behara and Van der Ven (2022)](https://doi.org/10.1103/PhysRevMaterials.6.054403)
also reports strain-coordinate paths, a two-shuffle landscape, and a switching
intermediate changed by fixing the O cell. Our two registered pattern-sign
candidates are not an enumeration of all its translational variants. Complete
cell fixing and the present partial substrate clamp define different ensembles.

## 11. Auditing a strong published parent reference

To avoid attributing a poor fixed-reference choice to a general failure of
fixed-mode models, the prospective comparison includes the Cmma parent of
[Qi and Rabe (2025)](https://doi.org/10.1103/9759-kp38). Its published input,
structure and displacement files are pinned by author commit and byte hashes.
The author's cell and coordinate frames are connected by an explicit proper
rotation, integer basis change, translation and species-preserving assignment;
an independent primitive-to-conventional reconstruction checks the rounded SI
coordinates. Assignment ambiguity, cell mismatch and unreported strain fitting
are rejected. An inconsistency in the printed structure table is retained,
not silently corrected. These operations do not alter a production image.

QE matdyn flvec stores normalized Cartesian displacements rather than
orthonormal mass-weighted dynamical-matrix eigenvectors. With the author masses
and original row order, we restore the mass metric and retain complex phases,
printed normalization and Gram defects. Rigid translations are identified by
subspace overlap; centering character is measured separately from any irrep
label. No acoustic sum rule or implicit orthogonalization is imposed, and
nonzero-q modes are not reclassified as Gamma modes. Only the first complete
Gamma block is imported.

This audit establishes consistency among representations of the published
reference, not its mapping onto a production path or its predictive accuracy.
Published LDA modes are candidate geometric directions, not PBE curvatures or
energies. Preparation of a real orthonormal comparison subspace, ordered-path
gauge mapping and same-data material benchmarking remain explicit gates.
The [source and numerical audit](../../benchmarks/hfo2_channels/20261008/cmma_reference/README.md)
records these limits. No material setting or running calculation is changed.

## 12. Reference registration and real geometric spans

The later production-path registration first uses the known stationary T
geometry to restrict192 proper signed-axis/quarter-origin candidates, then
uses the known common PO+ geometry to determine the closest Cmma registration.
All tied choices are retained. Modal coverage and energy are evaluated only
after registration. This is exploratory G1-informed choice, not a blind
test or proof of unique physical atom correspondence. The assignment is fixed
for reference rows and never changed image by image.

Let H_C and H_T be the rotated Cmma and original production T row cells.
Reference displacement directions are transported into a common fractional
chart as v_T=v_C H_C^{-1}H_T. This changes an analysis convention, not a
production geometry or Hamiltonian. In the declared mass metric, SVD of
[Re(V),Im(V)] supplies a real orthonormal span of prescribed rank. Complex
reconstruction errors and discarded singular values are reported; unexpected
rank or excessive error blocks the representation. No real-phase truncation,
ASR or new phonon-eigenpair interpretation is implicit in the operation.
Individual SVD axes are arbitrary; its projector and total span weight are
the invariant comparison quantities. Measured source translation admixture
is retained, while the geometric projection removes overall rigid translation
using the pre-existing common mass-metric contract.

Common-origin displacement fractions and reference-origin affine-plane
residuals answer different questions. Both use the same coordinate metric,
but the former compares directional coverage and the latter tests whether
an affine plane contains the endpoint/path. Their denominators are not mixed;
zero displacement is undefined rather than measured zero coverage. Complete
frequency doublets are retained in the equal-rank low-frequency T control.
Neither a high span fraction nor small projected curvature certifies full
stability, a conditional minimum or independently accurate barrier prediction.

## 13. Nonstationary restricted quadratic responses

The curvature-only Schur result in Section3 is insufficient at a generic
finite-image reference because the selected orthogonal gradient need not vanish.
`condition_quadratic_energy` therefore includes the affine response offset,
effective retained gradient and reference relaxation energy as well as K_eff.
It uses the same strict stable-block gate, but does not remove translations,
rescale units, substitute another reference Hessian or release omitted variables.
Analytic energy/gradient and frame-rotation tests verify the implementation.
The formula remains established harmonic mathematics, not our novelty claim.

For incomplete directional measurements, the model can be built in their
measured orthonormal span while every unmeasured coordinate remains fixed.
Raw reciprocity defects and any explicit symmetrization remain in the evidence.
The reference E, g, measured H, coordinate Jacobian and mechanical boundary
must all refer to the same center and calculator contract. A stationary T
Gamma matrix cannot supply missing blocks for a different, nonstationary image.

Sampling coverage is checked separately from the algebraic stable-block test.
Paired axis probes enclose a cross-polytope, not the full coordinate box; a
predicted relaxed position outside that convex hull is an extrapolation even
when each retained coordinate individually lies within its sampled range.
Neither hull inclusion nor a stable restricted block certifies a conditional
DFT minimum, unmeasured stability, branch continuity or barrier prediction.
Previously inspected step-size checks are explicitly retrospective, not newly
independent tests. The same-center [G0 pilot](../../benchmarks/hfo2_channels/20261008/restricted_quadratic/README.md)
illustrates both a measured mixed response and failure of released-point coverage.

## 14. Executable null controls and prospective output provenance

For a selected edge j and two matched-boundary training conditions x0,x1,
the direct control is B0_j(x*)=(1-w)B_j(x0)+wB_j(x1), with
w=(x*-x0)/(x1-x0). The selected representative uses lower-condition training
intervals only: candidates whose lower bound does not exceed the minimum
upper bound remain possible minima, and the preregistered lexical rule resolves
the representative, not the physical uncertainty. The same edge is retained
if the upper training condition selects a different candidate. Two held-out
edges do not supply the unseen network minimum.

Two zero-fit endpoint controls subtract the initial-well shift from the
anchor barrier: B1_fixed=B_j(x0)-Delta E_IS, or
B1_follow=B_j(x0)+Delta E_FS-Delta E_IS. Here the endpoint shifts are raw
cell-energy differences divided by the formula-unit count. Their assumptions
are respectively a fixed absolute bottleneck or one following the final well.
They are conventional null models, not new physics or observed behaviours.
Missing endpoint inputs remain unavailable and carry no implicit zero shift.
When supplied, target endpoint features and their complete DFT preparation
cost are visible inputs shared by all compared models.

The present endpoint-only feature schema is restricted to zero pressure.
Finite-pressure energy shifts require the corresponding volume/enthalpy
terms; raw E differences alone cannot supply Delta H. This unsupported use
is rejected rather than silently applied to the high-pressure GaN example.
Interpolation of audited training H barriers remains separately well-defined.

Propagation of the training-reference intervals through B0 does not bound
unseen-condition nonlinearity or prediction error; that error bound remains
unmeasured. An assumed bottleneck below either visible target endpoint violates
the endpoint-inclusive barrier definition. The raw signed prediction is retained
as an abstention, without clipping or correction using the target path. This
distinguishes failed assumptions from successful accurate forecasts.

A fresh output bundle records input/code/protocol hashes, predictions and
creation time before target path labels are read. The unread-label attestation
is explicit, but hashes/timestamps do not independently prove operator blinding.
The current implementation freezes B0/B1 controls, not a complete B2--B5
forecast batch. Real G2 training and independent material error/advantage
measurements remain incomplete. The [executable contract](../../docs/PREDICTION_CONTROLS.md)
and [negative G1 gate check](../../benchmarks/hfo2_channels/20261008/prediction_controls/README.md)
therefore document workflow preparation rather than a JCTC prediction result.

## 15. Prescribed strain is not an internal relaxation coordinate

To measure a mode-strain response, a local sampling chart must distinguish
the changing substrate parameter from the atomic and out-of-plane freedoms
released at each prescribed parameter. The implementation now augments the
exact fixed-plane chart with t=L(epsilon-epsilon0), using an explicitly
registered geometric scale L. Its first two row-cell vectors are
`H0[:2] * (1+epsilon)/(1+epsilon0)`; the third vector uses only the previous open
deformation basis. Atomic reference shifts retain the same ordered fractional
lift. All augmented coordinates and gradients use Angstrom and eV/Angstrom.

Physical stress work with the current cell/Jacobian supplies the controlled
gradient; d(E+PV)/d epsilon=L times its final component. Substrate reactions
do not enter internal convergence, but cannot be discarded from this external
work derivative. Mixed internal/control probes retain the complete gradient
and raw reciprocity defect. The control direction is never part of the
supplied internal release space and is not counted as a physical negative
direction in a fixed-epsilon saddle test.

This sampling chart is not an endpoint filter, a freely variable-cell path
optimizer or a certification of the envelope theorem's stationary-branch
premise. Existing fixed-epsilon BFGS/VCNEB boundaries remain unchanged.
Cu/EMT energy differences and actual uncomputed training-seed geometries
verify its implementation only. No new hafnia SCF, boundary-dependent barrier,
full Hessian or independent material forecast has been obtained by this step.
The [controlled-coordinate contract](../../docs/BIAXIAL_CONTROL_CURVATURE.md)
and [E027 receipt](../../benchmarks/hfo2_channels/20261008/biaxial_control/validation_delivery.json)
retain the precise metric, admissible space and validation limits.

## 16. Restricted stationary branches and paired response

The controlled coordinate remains prescribed while retained internal variables
follow a resolved index 0 or index 1 quadratic branch. Stable orthogonal release
retains the nonstationary offset and energy correction. Continuing the saddle's
negative internal direction is not stable minimization, so its controlled
curvature correction is not sign definite. The main-text Section 2.3 states
the equations; the [API](../../docs/CONTROLLED_STATIONARY_BRANCH.md) specifies
the admissible-space and index checks without declaring a full DFT TS.

The [paired interface](../../docs/STATIONARY_GAP_RESPONSE.md) requires matching
physical/boundary/control/energy declarations but uses each centre's own
external scale. It keeps raw gap, stationary-anchor correction, separate
increments and signed gap response. Declared intervals/radii are not proof
of probe-hull coverage; omission gradients and clamped reactions are retained.
No unconverged G1 peak or spring force is promoted to a stationary Hessian.

The actual material comparison may alternatively pair a bottleneck prediction
with visible audited target initial-well energy, as already allowed by the
prospective protocol. This avoids silently expanding the initial-well Hessian
budget. Every control must receive the same endpoint information and full
feature-preparation cost, and the input/calibration choice must be frozen
before complete target path labels. It is not zero-DFT prediction or proof
of a predicted initial-well response.

The [E031](../../benchmarks/hfo2_channels/20261008/stationary_branch/README.md)
and [E032](../../benchmarks/hfo2_channels/20261008/stationary_gap/README.md)
receipts document analytic solves, finite derivatives, clean full tests and
same-source HF replays only. Matched-boundary material training, complete
B2--B5 model freezing and independent accuracy/coverage remain incomplete.

## 17. Same-measurement response ablations and explicit coverage

The nested response interface receives a full physical gradient and measured
Hessian actions D=HM at one centre. M is an orthonormal real basis in the
declared atomic--cell chart; these are not derivatives of NEB or spring forces.
The admissible internal space, retained coordinates, atomic-only subspace
and prescribed-control direction are declared separately and checked.
Measured reciprocity must satisfy a caller-recorded numerical tolerance.

Writing K=sym(M^T D) and D_c=D+M(K-M^T D), the computational extension is
H_ext=D_c M^T+M D_c^T-M K M^T. Its unmeasured orthogonal block is unknown;
the zero completion is never used as evidence of stability. Each control
requires all of its retained, released and external directions inside M.
Full-gradient rows outside M remain available for omission diagnostics.
The dimension of missing internal coverage uses the span intersection, not
the rank of a nonzero projection onto M.

B2 freezes the complement of Q. B3 releases only the complement within the
atomic subspace and abstains when Q itself contains cell motion. B4 releases
the complete admissible complement only when it is measured and resolved
positive. The local B5 arm promotes all eigendirections at/below the
registered release floor before eliminating the remaining stable block.
The resulting combined internal block must still be nonsingular and have
the declared index. True zero curvature or an additional unstable direction
cannot be repaired by a pseudoinverse. External-control curvature is not
counted in that index. This implements local training-only promotion, not
selection among anharmonic branches; stable B4 and B5 are equivalent.

Both centres keep their individual control scales, nonstationary-anchor
corrections and measured source identities when responses are paired.
The API does not invent HfO2 curvature, certify an unmeasured complement,
freeze the material forecast batch or enlarge the two-bottleneck budget.
Where required information is unavailable within the registered budget,
the corresponding control remains unavailable rather than weakening the
strong reference or charging an unreported full Hessian as free.

Cost records count exact shared evaluations once while retaining every
supplied failed/unused preparation. Missing timings or allocations give
unknown totals and explicit partial sums, not zero-cost calls. Transport
wall time times assigned cores is a resource proxy, not CPU utilization.
The independent154-call pilot replay excludes previous endpoint and ongoing
continuation costs explicitly. Analytic48-point agreement validates only the
implementation, not DFT uncertainty, TS certification or prospective accuracy.
See the [nested control contract](../../docs/NESTED_RESPONSE_CONTROLS.md)
and [actual E055 evidence](../../benchmarks/hfo2_channels/20261008/nested_response_E055_20261010/README.md).

An additional full-joint harmonic null compares different retained subspaces,
not only rotations of a fixed subspace. With the same complete H, g, B and c,
all valid Q/R partitions give y*(t)=B u*(t)+c t, where
u*(t)=-(B^T H B)^(-1) B^T(g+Hct). Promotion changes the admissible partition,
not this complete stationary solution. The independent reference uses the
original full B directly;114stationary points and54paired gaps agree under
five partitions and two gauges. The frozen control is demonstrably different.
The direct full-B stationary solve remains an equal-information harmonic
reference when a particular stable-release partition is invalid; promotion
cannot claim a numerical advantage by excluding that computable reference.
Therefore a gain from changing reference or promoting directions cannot be
claimed merely from an exact complete quadratic response. Actual advantages
must arise from independently verified finite-data, nonharmonic, branch or
cost behavior. A conditional surface at prescribed Q is not this null.

The ten actual registered clamped geometry starters have36translation-free
internal directions (33atomic and3open-cell), plus one prescribed control.
One complete central-paired stencil would have37columns and75uncached
evaluations including the centre; two step lengths would have149. These are
prospective design counts for that stencil, not actual HfO2 Hessians, a
universal minimum, or an added allowance. Surface nodes and curvature/cost
preparation must be accounted separately; neither a smooth frozen plane nor
the81surface-node cap supplies unmeasured full curvature. Exact overlap and
the actual finite probe budget must be declared before DFT submission.

## 18. Seen endpoint strain-work diagnostic and well-only null increments

For ASE row cells H and fractional coordinates s, r=sH. At fixed external
pressure P, the physical directional work for a control t is

```text
d(E+PV)/dt = V (sigma+P I) : [(dH/dt)^T H^-T]
            - sum_i F_i dot [(ds_i/dt)H].
```

The stress is tensile-positive in eV/Angstrom^3; forces are eV/Angstrom.
Neither a mass metric, a shear factor two nor the numerical VCNEB cell-scale
parameter belongs in this scalar work. The atomic term represents internal
fractional-coordinate motion only, so affine cell motion is not counted twice.
Independent scalar-energy finite differences cover mixed cell/atom changes,
fixed pressure, oblique rotations and shear. The API is calculator-free.

The actual ten screened training endpoint representations at epsilon0/.01
retain the common substrate, P=0 and original100Ry/full10auDZP inputs.
For the imposed-plane partial, set dH[:2]/d epsilon=H[:2]/(1+epsilon) and
dH[2]=0. Nonzero force/open traction is explicitly retained: only at exact
stationarity could the partial become a stationary-branch envelope derivative.
A separate diagnostic uses dH=(H1-H0)/.01 and ds=(s1-s0)/.01 in the original
registered ordered endpoint/history lifts. It is a configuration chord, not
a relaxed intermediate branch or a new optimized path. No remapping or new
DFT is performed. The trapezoids use only endpoint derivatives; their signed
energy defects are observations, never independent curvature/noise bounds.

The original B1 assumptions are evaluated only as seen-training increments:
fixed absolute bottleneck gives -delta E_PO+, and final-following bottleneck
gives delta E_FS-delta E_PO+. Absolute anchor barriers, training-network
selection, actual bottleneck response, B0/B2--B5 forecasts and complete
freeze remain unavailable at this stage. Endpoint data are seen features,
not held-out labels. Full asset bytes remain on HF; offline output states
which original raw hashes and historical HF physical-byte checks it uses.
Source, raw-audit and log hashes and all four null increments are retained
in the [E059 analysis](../../benchmarks/hfo2_channels/20261008/endpoint_strain_work_E059_20261010/README.md)
and [work API](../../docs/STRAIN_WORK.md). Neither sub-meV trapezoid defects
nor phase labels certify a barrier, TS, full Hessian or material prediction gain.
